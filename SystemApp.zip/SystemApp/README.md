# System

Solo Leveling style quest app. Quests have locked times; a missed quest rings an alarm until you send photo proof.

## Build the APK on GitHub
1. Push this project to a GitHub repo (branch `main`).
2. Open the repo, tab **Actions**, workflow **Build APK** (runs automatically on every push, or press **Run workflow**).
3. When it turns green, open the run and download **System-debug-apk** under **Artifacts**. Unzip it to get `app-debug.apk`.
4. Install the APK on your phone (allow "Install unknown apps" for your browser or file manager).

## Push from a phone with Termux
```
pkg install git unzip
unzip SystemApp.zip && cd SystemApp
git init -b main
git add -A && git commit -m "System app"
git remote add origin https://github.com/YOUR_USER/YOUR_REPO.git
git push -u origin main
```
Use a GitHub Personal Access Token (repo scope) as the password.
