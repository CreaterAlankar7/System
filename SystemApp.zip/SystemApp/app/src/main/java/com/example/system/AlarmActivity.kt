package com.example.system

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class AlarmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true); setTurnScreenOn(true); enableEdgeToEdge()
        val id = intent.getLongExtra("id", 0)
        val q = Store.quests(this).find { it.id == id }
        setContent {
            var left by remember { mutableLongStateOf(AlarmService.endAt - System.currentTimeMillis()) }
            val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
                if (bmp != null) {
                    startService(Intent(this@AlarmActivity, AlarmService::class.java).putExtra("id", id).putExtra("stop", true))
                    finish()
                }
            }
            LaunchedEffect(Unit) {
                while (true) {
                    left = AlarmService.endAt - System.currentTimeMillis()
                    if (AlarmService.activeId != id || left <= 0) { finish(); break }
                    delay(500)
                }
            }
            val s = maxOf(0L, left / 1000)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A0308), Void))).statusBarsPadding().padding(24.dp), Alignment.Center) {
                SystemPanel(danger = true) {
                    Text("[ WARNING ]", color = Danger, fontFamily = Mono, fontSize = 14.sp, letterSpacing = 4.sp)
                    Spacer(Modifier.height(14.dp))
                    Text(q?.name ?: "Quest", color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Quest incomplete. Send proof or face the penalty.", color = Dim, fontFamily = Mono, fontSize = 14.sp)
                    Spacer(Modifier.height(18.dp))
                    Text("%02d:%02d".format(s / 60, s % 60), color = Danger, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 44.sp)
                    Spacer(Modifier.height(20.dp))
                    SystemButton("SEND PROOF", danger = true) { cam.launch(null) }
                }
            }
        }
    }
}
