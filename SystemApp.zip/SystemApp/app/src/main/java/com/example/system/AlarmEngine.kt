package com.example.system

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*
import androidx.core.content.ContextCompat
import java.util.Calendar

object Alarms {
    fun schedule(c: Context, q: Quest) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, q.hour); set(Calendar.MINUTE, q.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(c, q.id.toInt(), Intent(c, AlarmReceiver::class.java).putExtra("id", q.id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        c.getSystemService(AlarmManager::class.java).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val q = Store.quests(c).find { it.id == i.getLongExtra("id", 0) } ?: return
        Alarms.schedule(c, q)
        if (Store.status(c, q.id) != "cleared")
            ContextCompat.startForegroundService(c, Intent(c, AlarmService::class.java).putExtra("id", q.id))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Store.quests(c).forEach { Alarms.schedule(c, it) } }
}

class AlarmService : Service() {
    companion object { @Volatile var activeId = 0L; @Volatile var endAt = 0L }
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val id = i?.getLongExtra("id", 0) ?: 0
        if (i?.getBooleanExtra("stop", false) == true) {
            if (activeId == id) { Store.clear(this, id); finish() } else stopSelf()
            return START_NOT_STICKY
        }
        val q = Store.quests(this).find { it.id == id }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("alarm", "Quest alarm", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, AlarmActivity::class.java).putExtra("id", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "alarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("[SYSTEM] WARNING").setContentText("Quest not done: ${q?.name}")
            .setCategory(Notification.CATEGORY_ALARM).setFullScreenIntent(pi, true).setContentIntent(pi).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(1, n)
        activeId = id
        endAt = System.currentTimeMillis() + Store.window(this) * 60_000L
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        mp = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            setDataSource(this@AlarmService, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            isLooping = true; prepare(); start()
        }
        h.postDelayed({ Store.fail(this, id); finish() }, endAt - System.currentTimeMillis())
        return START_NOT_STICKY
    }

    private fun finish() {
        activeId = 0; mp?.release(); mp = null; h.removeCallbacksAndMessages(null)
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }
    override fun onDestroy() { mp?.release(); h.removeCallbacksAndMessages(null) }
}
