package com.example.system

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Mono = FontFamily.Monospace

@Composable
fun SystemPanel(danger: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        0.35f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse), label = "a"
    )
    val c = if (danger) Danger else Neon
    val shape = CutCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(PanelBg)
            .border(1.5.dp, Brush.linearGradient(listOf(c.copy(alpha = pulse), Cyan.copy(alpha = 0.25f), c.copy(alpha = pulse))), shape)
            .padding(24.dp),
        content = content
    )
}

@Composable
fun SystemButton(text: String, danger: Boolean = false, onClick: () -> Unit) {
    val c = if (danger) Danger else Neon
    val shape = CutCornerShape(10.dp)
    Box(
        Modifier.fillMaxWidth().clip(shape).background(c.copy(alpha = 0.15f))
            .border(1.5.dp, c, shape).clickable(onClick = onClick).padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 3.sp) }
}

@Composable
fun StepDots(total: Int, done: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        repeat(total) { i ->
            Box(
                Modifier.size(width = 34.dp, height = 6.dp).clip(CutCornerShape(2.dp))
                    .background(if (i < done) Cyan else if (i == done) Neon.copy(alpha = 0.6f) else Color(0xFF16284A))
            )
        }
    }
}
