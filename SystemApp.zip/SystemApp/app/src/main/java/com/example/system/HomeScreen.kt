package com.example.system

import android.app.TimePickerDialog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun HomeScreen() {
    val c = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    var proofFor by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) { while (true) { delay(1500); rev++ } }
    val quests = remember(rev) { Store.quests(c) }
    val xp = remember(rev) { Store.xp(c) }
    val lvl = xp / 100 + 1
    val rank = "EDCBAS"[minOf(5, lvl / 5)]
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { b ->
        if (b != null) { Store.clear(c, proofFor); rev++ }
    }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Void, Deep))).statusBarsPadding().padding(20.dp)) {
        SystemPanel {
            Text("[ PLAYER ]", color = Cyan, fontFamily = Mono, fontSize = 13.sp, letterSpacing = 4.sp)
            Spacer(Modifier.height(10.dp))
            Text("RANK $rank   LV $lvl", color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 26.sp)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(8.dp).background(Deep)) { Box(Modifier.fillMaxWidth((xp % 100) / 100f).fillMaxHeight().background(Neon)) }
            Spacer(Modifier.height(6.dp))
            Text("${xp % 100}/100 XP   |   alarm window ${Store.window(c)} min", color = Dim, fontFamily = Mono, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(quests) { q ->
                val st = Store.status(c, q.id)
                SystemPanel(danger = st == "failed") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(q.name, color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("%02d:%02d  |  %s".format(q.hour, q.minute, st.uppercase()), color = Dim, fontFamily = Mono, fontSize = 12.sp)
                        }
                        if (st == "pending") Box(Modifier.width(110.dp)) { SystemButton("PROOF") { proofFor = q.id; cam.launch(null) } }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        SystemButton("+ NEW QUEST") { adding = true }
    }
    if (adding) AddDialog({ adding = false }) { rev++; adding = false }
}

@Composable
fun AddDialog(onClose: () -> Unit, onSaved: () -> Unit) {
    val c = LocalContext.current
    var name by remember { mutableStateOf("") }
    var h by remember { mutableIntStateOf(-1) }
    var m by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onClose, containerColor = Deep, shape = CutCornerShape(14.dp),
        title = { Text("[ NEW QUEST ]", color = Cyan, fontFamily = Mono, fontSize = 16.sp, letterSpacing = 3.sp) },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Quest name") }, singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Cyan, unfocusedTextColor = Cyan, focusedBorderColor = Neon,
                        unfocusedBorderColor = Dim, cursorColor = Cyan, focusedLabelColor = Cyan, unfocusedLabelColor = Dim))
                Spacer(Modifier.height(14.dp))
                SystemButton(if (h < 0) "SET TIME" else "%02d:%02d".format(h, m)) {
                    TimePickerDialog(c, { _, hh, mm -> h = hh; m = mm }, 8, 0, true).show()
                }
                Spacer(Modifier.height(10.dp))
                Text("Time is locked once saved. It cannot be changed.", color = Danger, fontFamily = Mono, fontSize = 12.sp)
            }
        },
        confirmButton = {
            SystemButton("LOCK QUEST") {
                if (name.isNotBlank() && h >= 0) {
                    val q = Quest(System.currentTimeMillis(), name.trim(), h, m)
                    Store.add(c, q); Alarms.schedule(c, q); onSaved()
                }
            }
        }
    )
}
