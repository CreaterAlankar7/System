package com.example.system

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay

enum class Perm(val tag: String, val line: String) {
    NOTIF("NOTIFICATIONS", "The System must warn you when a quest begins."),
    ALARM("EXACT ALARM", "Quests trigger at the exact second. No delay allowed."),
    FULLSCREEN("FULL-SCREEN ALERT", "The alarm must reach you even on a locked screen."),
    CAMERA("CAMERA", "Photo proof is the only way to silence the alarm."),
    BATTERY("UNRESTRICTED BATTERY", "The System must keep running in the background.")
}

fun isGranted(c: Context, p: Perm): Boolean = when (p) {
    Perm.NOTIF -> Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    Perm.ALARM -> Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    Perm.FULLSCREEN -> Build.VERSION.SDK_INT < 34 || c.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
    Perm.CAMERA -> c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    Perm.BATTERY -> c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
}

fun allGranted(c: Context) = Perm.values().all { isGranted(c, it) }

private fun settingsIntent(c: Context, p: Perm): Intent {
    val uri = Uri.parse("package:${c.packageName}")
    val details = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
    return when (p) {
        Perm.ALARM -> if (Build.VERSION.SDK_INT >= 31) Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, uri) else details
        Perm.FULLSCREEN -> if (Build.VERSION.SDK_INT >= 34) Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, uri) else details
        Perm.BATTERY -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, uri)
        else -> details
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun PermissionFlow(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var denials by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) denials++ else denials = 0
        tick++
    }
    val current = remember(tick) { Perm.values().firstOrNull { !isGranted(ctx, it) } }
    LaunchedEffect(current) { if (current == null) { delay(1600); onDone() } }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Void, Deep))).statusBarsPadding().padding(24.dp)) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            StepDots(Perm.values().size, current?.ordinal ?: Perm.values().size)
            Spacer(Modifier.height(28.dp))
            AnimatedContent(
                targetState = current,
                transitionSpec = { (fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 8 }) togetherWith fadeOut(tween(200)) },
                label = "step"
            ) { p ->
                if (p == null) {
                    SystemPanel {
                        Text("[ SYSTEM ]", color = Cyan, fontFamily = Mono, fontSize = 13.sp, letterSpacing = 4.sp)
                        Spacer(Modifier.height(14.dp))
                        Text("SETUP COMPLETE", color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("Welcome, Player.", color = Dim, fontFamily = Mono, fontSize = 14.sp)
                    }
                } else {
                    val denied = denials > 0
                    val runtime = p == Perm.NOTIF || p == Perm.CAMERA
                    SystemPanel(danger = denied) {
                        Text("[ SYSTEM ]", color = if (denied) Danger else Cyan, fontFamily = Mono, fontSize = 13.sp, letterSpacing = 4.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("Permission required", color = Dim, fontFamily = Mono, fontSize = 13.sp)
                        Spacer(Modifier.height(16.dp))
                        Text(p.tag, color = Cyan, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        Spacer(Modifier.height(10.dp))
                        Text(p.line, color = Dim, fontFamily = Mono, fontSize = 14.sp, lineHeight = 20.sp)
                        if (denied) {
                            Spacer(Modifier.height(14.dp))
                            Text("Access denied. This step cannot be skipped.", color = Danger, fontFamily = Mono, fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(22.dp))
                        SystemButton(if (denials >= 2 && runtime) "OPEN SETTINGS" else "ALLOW", danger = denied) {
                            when {
                                !runtime || denials >= 2 -> ctx.startActivity(settingsIntent(ctx, p))
                                p == Perm.NOTIF -> launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                else -> launcher.launch(Manifest.permission.CAMERA)
                            }
                        }
                    }
                }
            }
        }
    }
}
