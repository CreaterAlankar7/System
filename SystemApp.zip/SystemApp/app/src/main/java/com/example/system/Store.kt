package com.example.system

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Quest(val id: Long, val name: String, val hour: Int, val minute: Int)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("system", 0)
    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    fun quests(c: Context): List<Quest> {
        val a = JSONArray(p(c).getString("q", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it); Quest(o.getLong("id"), o.getString("n"), o.getInt("h"), o.getInt("m")) }
    }
    fun add(c: Context, q: Quest) {
        val a = JSONArray(p(c).getString("q", "[]"))
        a.put(JSONObject().put("id", q.id).put("n", q.name).put("h", q.hour).put("m", q.minute))
        p(c).edit().putString("q", a.toString()).apply()
    }
    fun xp(c: Context) = p(c).getInt("xp", 0)
    fun window(c: Context) = p(c).getInt("w", 10)
    fun status(c: Context, id: Long): String {
        val s = p(c).getString("s$id", "") ?: ""
        return if (s.startsWith(today())) s.substring(9) else "pending"
    }
    fun clear(c: Context, id: Long) {
        if (status(c, id) == "cleared") return
        p(c).edit().putString("s$id", today() + ":cleared").putInt("xp", xp(c) + 25).putInt("f", 0).apply()
    }
    fun fail(c: Context, id: Long) {
        val f = p(c).getInt("f", 0) + 1
        val e = p(c).edit().putString("s$id", today() + ":failed").putInt("xp", maxOf(0, xp(c) - 15))
        if (f >= 3) e.putInt("w", minOf(30, window(c) + 5)).putInt("f", 0) else e.putInt("f", f)
        e.apply()
    }
}
