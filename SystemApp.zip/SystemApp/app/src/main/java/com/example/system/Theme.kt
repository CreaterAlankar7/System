package com.example.system

import androidx.compose.ui.graphics.Color

val Void = Color(0xFF040A16)
val Deep = Color(0xFF071530)
val PanelBg = Color(0xE60A1630)
val Neon = Color(0xFF3AA0FF)
val Cyan = Color(0xFF00E5FF)
val Danger = Color(0xFFFF3B4E)
val Dim = Color(0xFF7FA8D9)
